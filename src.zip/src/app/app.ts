import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Header } from './header/header';
import { SearchBar } from './search-bar/search-bar';
import { CardHolder } from './card-holder/card-holder';

@Component({
  selector: 'app-root',
  imports: [Header, SearchBar, CardHolder],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  searchText = signal<string>('');
  selectBox = signal<Number>(0);

  onSelectChange(value: Number) {
    this.selectBox.set(value);
  }

  onSearchChange(value: string) {
    this.searchText.set(value);
  }
}
