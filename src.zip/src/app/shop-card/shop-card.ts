import { Component, Input } from '@angular/core';
import { Product } from '../Services/api-call-service';

@Component({
  selector: 'app-shop-card',
  imports: [],
  templateUrl: './shop-card.html',
  styleUrl: './shop-card.css',
})
export class ShopCard {
  @Input() card!: Product;
}
